
// Sample movie data for our Netflix clone
export type Movie = {
  id: string;
  title: string;
  type: 'movie' | 'series';
  genre: string[];
  imageUrl: string;
  year: number;
  rating: number;
  description: string;
};

// Mock movie data
const movies: Movie[] = [
  {
    id: '1',
    title: 'Stranger Things',
    type: 'series',
    genre: ['Sci-Fi', 'Horror', 'Drama'],
    imageUrl: 'https://images.unsplash.com/photo-1500375592092-40eb2168fd21',
    year: 2016,
    rating: 4.8,
    description: 'When a young boy disappears, his mother, a police chief, and his friends must confront terrifying supernatural forces in order to get him back.'
  },
  {
    id: '2',
    title: 'The Matrix',
    type: 'movie',
    genre: ['Sci-Fi', 'Action'],
    imageUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5',
    year: 1999,
    rating: 4.7,
    description: 'A computer hacker learns from mysterious rebels about the true nature of his reality and his role in the war against its controllers.'
  },
  {
    id: '3',
    title: 'Breaking Bad',
    type: 'series',
    genre: ['Crime', 'Drama', 'Thriller'],
    imageUrl: 'https://images.unsplash.com/photo-1500673922987-e212871fec22',
    year: 2008,
    rating: 4.9,
    description: 'A high school chemistry teacher diagnosed with inoperable lung cancer turns to manufacturing and selling methamphetamine in order to secure his family\'s future.'
  },
  {
    id: '4',
    title: 'Inception',
    type: 'movie',
    genre: ['Sci-Fi', 'Action', 'Adventure'],
    imageUrl: 'https://images.unsplash.com/photo-1581090464777-f3220bbe1b8b',
    year: 2010,
    rating: 4.8,
    description: 'A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O.'
  },
  {
    id: '5',
    title: 'The Crown',
    type: 'series',
    genre: ['Drama', 'History'],
    imageUrl: 'https://images.unsplash.com/photo-1721322800607-8c38375eef04',
    year: 2016,
    rating: 4.7,
    description: 'Follows the political rivalries and romance of Queen Elizabeth II\'s reign and the events that shaped the second half of the twentieth century.'
  },
  {
    id: '6',
    title: 'Interstellar',
    type: 'movie',
    genre: ['Sci-Fi', 'Adventure', 'Drama'],
    imageUrl: 'https://images.unsplash.com/photo-1500673922987-e212871fec22',
    year: 2014,
    rating: 4.8,
    description: 'A team of explorers travel through a wormhole in space in an attempt to ensure humanity\'s survival.'
  },
  {
    id: '7',
    title: 'Mindhunter',
    type: 'series',
    genre: ['Crime', 'Drama', 'Thriller'],
    imageUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5',
    year: 2017,
    rating: 4.7,
    description: 'In the late 1970s, two FBI agents expand criminal science by delving into the psychology of murder and getting uneasily close to all-too-real monsters.'
  },
  {
    id: '8',
    title: 'Dune',
    type: 'movie',
    genre: ['Adventure', 'Drama', 'Sci-Fi'],
    imageUrl: 'https://images.unsplash.com/photo-1581090464777-f3220bbe1b8b',
    year: 2021,
    rating: 4.6,
    description: 'Feature adaptation of Frank Herbert\'s science fiction novel about the son of a noble family entrusted with the protection of the most valuable asset and most vital element in the galaxy.'
  },
];

// API methods
export const api = {
  getMovies: () => {
    return Promise.resolve(movies);
  },
  
  getMovieById: (id: string) => {
    const movie = movies.find(m => m.id === id);
    return Promise.resolve(movie);
  },
  
  getMoviesByType: (type: 'movie' | 'series') => {
    const filteredMovies = movies.filter(m => m.type === type);
    return Promise.resolve(filteredMovies);
  },
  
  searchMovies: (query: string) => {
    const searchResults = movies.filter(
      m => m.title.toLowerCase().includes(query.toLowerCase()) || 
           m.genre.some(g => g.toLowerCase().includes(query.toLowerCase()))
    );
    return Promise.resolve(searchResults);
  },
  
  getCategories: () => {
    // All unique genres
    const allGenres = movies.flatMap(m => m.genre);
    const uniqueGenres = [...new Set(allGenres)];
    return Promise.resolve(uniqueGenres);
  },
  
  getMoviesByGenre: (genre: string) => {
    const filteredMovies = movies.filter(m => m.genre.includes(genre));
    return Promise.resolve(filteredMovies);
  },
};
