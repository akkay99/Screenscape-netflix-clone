
import React, { useState, useEffect } from 'react';
import { api, Movie } from '@/services/api';
import Navbar from '@/components/Navbar';
import MovieCard from '@/components/MovieCard';
import { Input } from '@/components/ui/input';
import { Search as SearchIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

const SearchPage: React.FC = () => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Movie[]>([]);
  const [allMovies, setAllMovies] = useState<Movie[]>([]);
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    const fetchMovies = async () => {
      try {
        const movies = await api.getMovies();
        setAllMovies(movies);
      } catch (error) {
        console.error('Error fetching movies:', error);
      }
    };
    
    fetchMovies();
  }, [isAuthenticated, navigate]);

  useEffect(() => {
    const searchMovies = async () => {
      if (query.length === 0) {
        setResults(allMovies);
        return;
      }
      
      try {
        const searchResults = await api.searchMovies(query);
        setResults(searchResults);
      } catch (error) {
        console.error('Error searching movies:', error);
      }
    };
    
    searchMovies();
  }, [query, allMovies]);

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-netflix-black">
      <Navbar />
      
      <div className="pt-28 pb-20 px-4 md:px-16">
        <div className="relative w-full max-w-2xl mb-8 mx-auto">
          <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
          <Input 
            type="text"
            placeholder="Search for movies, series, genres..."
            className="pl-10 py-6 bg-netflix-medium-gray text-white border-none focus-visible:ring-netflix-red w-full"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        
        <div className="mt-8">
          <h2 className="text-white text-xl font-medium mb-4">
            {query ? `Results for "${query}"` : 'All Titles'}
          </h2>
          
          {results.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-400 text-lg">No results found</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {results.map((movie) => (
                <div key={movie.id}>
                  <MovieCard 
                    movie={movie} 
                    onClick={() => navigate(`/details/${movie.id}`)}
                  />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SearchPage;
