
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { api, Movie } from '@/services/api';
import Navbar from '@/components/Navbar';
import { Button } from '@/components/ui/button';
import CategoryRow from '@/components/CategoryRow';
import { useAuth } from '@/contexts/AuthContext';

const MovieDetailsPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [movie, setMovie] = useState<Movie | null>(null);
  const [similarMovies, setSimilarMovies] = useState<Movie[]>([]);
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    const fetchMovie = async () => {
      if (!id) return;
      
      try {
        const movieData = await api.getMovieById(id);
        if (!movieData) {
          navigate('/not-found');
          return;
        }
        
        setMovie(movieData);
        
        // Get similar movies (same genre)
        if (movieData.genre && movieData.genre.length > 0) {
          const genre = movieData.genre[0];
          const similar = await api.getMoviesByGenre(genre);
          // Filter out the current movie
          setSimilarMovies(similar.filter(m => m.id !== id));
        }
      } catch (error) {
        console.error('Error fetching movie details:', error);
      }
    };
    
    fetchMovie();
  }, [id, isAuthenticated, navigate]);

  if (!isAuthenticated || !movie) {
    return null;
  }

  return (
    <div className="min-h-screen bg-netflix-black">
      <Navbar />
      
      <div className="relative">
        {/* Hero Section */}
        <div className="relative h-[70vh] w-full">
          <div className="absolute inset-0">
            <img 
              src={movie.imageUrl} 
              alt={movie.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-netflix-black to-netflix-black/10" />
            <div className="absolute inset-0 bg-gradient-to-t from-netflix-black via-transparent to-netflix-black/40" />
          </div>
        </div>
        
        {/* Content Section */}
        <div className="relative px-4 md:px-16 pb-20 -mt-40">
          <div className="max-w-3xl">
            <h1 className="text-white text-3xl md:text-5xl font-bold mb-4">{movie.title}</h1>
            
            <div className="flex items-center mb-6">
              <span className="text-green-400 mr-2 font-medium">{movie.rating.toFixed(1)} Rating</span>
              <span className="text-gray-400 mx-2">|</span>
              <span className="text-gray-200">{movie.year}</span>
              <span className="text-gray-400 mx-2">|</span>
              <span className="text-gray-200 capitalize">{movie.type}</span>
            </div>
            
            <p className="text-gray-300 text-base md:text-lg mb-8">
              {movie.description}
            </p>
            
            <div className="flex flex-wrap gap-2 mb-6">
              {movie.genre.map((genre, index) => (
                <span key={index} className="px-3 py-1 bg-netflix-medium-gray text-gray-300 rounded-full text-sm">
                  {genre}
                </span>
              ))}
            </div>
            
            <div className="flex space-x-4 mb-12">
              <Button className="bg-netflix-red hover:bg-netflix-red/80 text-white px-8 py-5">
                Play
              </Button>
              <Button className="bg-gray-600 hover:bg-gray-600/80 text-white px-8 py-5">
                My List
              </Button>
            </div>
          </div>
          
          {/* Similar Content */}
          {similarMovies.length > 0 && (
            <div className="mt-12">
              <CategoryRow 
                title={`More like ${movie.title}`} 
                movies={similarMovies}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MovieDetailsPage;
