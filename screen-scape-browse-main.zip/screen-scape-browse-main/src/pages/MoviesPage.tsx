import React, { useEffect, useState } from 'react';
import { api, Movie } from '@/services/api';
import CategoryRow from '@/components/CategoryRow';
import Navbar from '@/components/Navbar';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

const MoviesPage: React.FC = () => {
  const [movies, setMovies] = useState<Movie[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [categoryMovies, setCategoryMovies] = useState<Record<string, Movie[]>>({});
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    const fetchData = async () => {
      try {
        const moviesList = await api.getMoviesByType('movie');
        const categoriesList = await api.getCategories();
        
        setMovies(moviesList);
        setCategories(categoriesList);
        
        // Fetch movies for each category
        const categoryData: Record<string, Movie[]> = {};
        for (const category of categoriesList) {
          const moviesInCategory = await api.getMoviesByGenre(category);
          // Only keep movies, not series
          categoryData[category] = moviesInCategory.filter(m => m.type === 'movie');
        }
        setCategoryMovies(categoryData);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
    
    fetchData();
  }, [isAuthenticated, navigate]);

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-netflix-black">
      <Navbar />
      
      <div className="pt-28 pb-20 px-4 md:px-16 space-y-8">
        <h1 className="text-white text-3xl md:text-4xl font-bold mb-8">Movies</h1>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {/* Movie grid */}
        </div>
        
        <CategoryRow title="All Movies" movies={movies} />
        
        {categories.map((category) => {
          const moviesInCategory = categoryMovies[category] || [];
          if (moviesInCategory.length === 0) return null;
          
          return (
            <CategoryRow 
              key={category} 
              title={category} 
              movies={moviesInCategory} 
            />
          );
        })}
      </div>
    </div>
  );
};

export default MoviesPage;
