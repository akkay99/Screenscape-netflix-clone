import React, { useEffect, useState } from 'react';
import { api, Movie } from '@/services/api';
import CategoryRow from '@/components/CategoryRow';
import Navbar from '@/components/Navbar';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

const SeriesPage: React.FC = () => {
  const [series, setSeries] = useState<Movie[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [categorySeries, setCategorySeries] = useState<Record<string, Movie[]>>({});
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    const fetchData = async () => {
      try {
        const seriesList = await api.getMoviesByType('series');
        const categoriesList = await api.getCategories();
        
        setSeries(seriesList);
        setCategories(categoriesList);
        
        // Fetch series for each category
        const categoryData: Record<string, Movie[]> = {};
        for (const category of categoriesList) {
          const seriesInCategory = await api.getMoviesByGenre(category);
          // Only keep series, not movies
          categoryData[category] = seriesInCategory.filter(m => m.type === 'series');
        }
        setCategorySeries(categoryData);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
    
    fetchData();
  }, [isAuthenticated, navigate]);

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-netflix-black">
      <Navbar />
      
      <div className="pt-28 pb-20 px-4 md:px-16 space-y-8">
        <h1 className="text-white text-3xl md:text-4xl font-bold mb-8">Series</h1>
        
        <CategoryRow title="All Series" movies={series} />
        
        {categories.map((category) => {
          const seriesInCategory = categorySeries[category] || [];
          if (seriesInCategory.length === 0) return null;
          
          return (
            <CategoryRow 
              key={category} 
              title={category} 
              movies={seriesInCategory} 
            />
          );
        })}
      </div>
    </div>
  );
};

export default SeriesPage;
