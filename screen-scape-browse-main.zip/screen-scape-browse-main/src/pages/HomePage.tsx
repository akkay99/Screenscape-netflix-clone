
import React, { useEffect, useState } from 'react';
import { api, Movie } from '@/services/api';
import CategoryRow from '@/components/CategoryRow';
import FeatureBanner from '@/components/FeatureBanner';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

const HomePage: React.FC = () => {
  const [movies, setMovies] = useState<Movie[]>([]);
  const [series, setSeries] = useState<Movie[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [featuredContent, setFeaturedContent] = useState<Movie | null>(null);
  const [categoryMovies, setCategoryMovies] = useState<Record<string, Movie[]>>({});
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    const fetchData = async () => {
      try {
        const allMovies = await api.getMovies();
        const moviesList = await api.getMoviesByType('movie');
        const seriesList = await api.getMoviesByType('series');
        const categoriesList = await api.getCategories();
        
        // Get a random movie for the featured banner
        const randomIndex = Math.floor(Math.random() * allMovies.length);
        
        setMovies(moviesList);
        setSeries(seriesList);
        setCategories(categoriesList);
        setFeaturedContent(allMovies[randomIndex]);
        
        // Fetch movies for each category
        const categoryData: Record<string, Movie[]> = {};
        for (const category of categoriesList) {
          const moviesInCategory = await api.getMoviesByGenre(category);
          categoryData[category] = moviesInCategory;
        }
        setCategoryMovies(categoryData);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };
    
    fetchData();
  }, [isAuthenticated, navigate]);

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-netflix-black pb-20">
      {featuredContent && <FeatureBanner movie={featuredContent} />}
      
      <div className="px-4 md:px-16 mt-8 space-y-8">
        <CategoryRow title="Popular Movies" movies={movies} />
        <CategoryRow title="Popular Series" movies={series} />
        
        {categories.map((category) => (
          <CategoryRow 
            key={category} 
            title={category} 
            movies={categoryMovies[category] || []} 
          />
        ))}
      </div>
    </div>
  );
};

export default HomePage;
