
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

const NotFound: React.FC = () => {
  return (
    <div className="min-h-screen bg-netflix-black flex flex-col items-center justify-center p-4">
      <h1 className="text-netflix-red text-6xl md:text-8xl font-bold mb-4">404</h1>
      <p className="text-white text-xl md:text-2xl mb-8">Lost your way?</p>
      <p className="text-gray-400 text-center max-w-md mb-8">
        Sorry, we can't find that page. You'll find lots to explore on the home page.
      </p>
      <Button asChild className="bg-netflix-red hover:bg-netflix-red/80 text-white">
        <Link to="/">Back to Home</Link>
      </Button>
    </div>
  );
};

export default NotFound;
