
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';

const LoginPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !password) {
      toast({
        title: "Error",
        description: "Please enter both email and password",
        variant: "destructive"
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      await login(email, password);
      navigate('/');
    } catch (error) {
      let message = "Invalid credentials";
      if (error instanceof Error) {
        message = error.message;
      }
      
      toast({
        title: "Login Failed",
        description: message,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div 
      className="min-h-screen w-full flex items-center justify-center bg-cover bg-center"
      style={{ 
        backgroundImage: "linear-gradient(rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0.8)), url(https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5)"
      }}
    >
      <Card className="w-full max-w-md mx-4 bg-netflix-dark-gray/90 border-none text-white">
        <CardHeader>
          <CardTitle className="text-2xl text-center mb-2">Sign In</CardTitle>
          <CardDescription className="text-gray-400 text-center">
            Use demo@example.com / password to login
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Input
                type="email"
                placeholder="Email"
                className="bg-netflix-medium-gray/50 border-gray-700 text-white h-12"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Input
                type="password"
                placeholder="Password"
                className="bg-netflix-medium-gray/50 border-gray-700 text-white h-12"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            <Button 
              type="submit" 
              className="w-full bg-netflix-red hover:bg-netflix-red/80 text-white font-medium h-12"
              disabled={isLoading}
            >
              {isLoading ? "Signing in..." : "Sign In"}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex flex-col space-y-4">
          <div className="text-gray-400 text-sm text-center">
            <p>This is a demo application. Use the credentials:</p>
            <p className="font-medium text-gray-300">Email: demo@example.com</p>
            <p className="font-medium text-gray-300">Password: password</p>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
};

export default LoginPage;
