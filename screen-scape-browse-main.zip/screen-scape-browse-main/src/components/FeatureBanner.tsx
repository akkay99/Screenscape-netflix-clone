
import React from 'react';
import { Movie } from '@/services/api';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

interface FeatureBannerProps {
  movie: Movie;
}

const FeatureBanner: React.FC<FeatureBannerProps> = ({ movie }) => {
  const navigate = useNavigate();

  return (
    <div className="relative h-[56.25vw] md:h-[70vh] lg:h-[80vh] w-full">
      <div className="absolute inset-0">
        <img 
          src={movie.imageUrl} 
          alt={movie.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-netflix-black to-netflix-black/10" />
        <div className="absolute inset-0 bg-gradient-to-t from-netflix-black via-transparent to-netflix-black/40" />
      </div>
      
      <div className="absolute bottom-[30%] left-4 md:left-16 max-w-xl z-10">
        <h1 className="text-white text-2xl md:text-4xl lg:text-6xl font-bold mb-3 md:mb-4">
          {movie.title}
        </h1>
        <div className="flex items-center mb-3 md:mb-4">
          <span className="text-green-400 mr-2 font-medium">{movie.rating.toFixed(1)} Rating</span>
          <span className="text-gray-400 mx-2">|</span>
          <span className="text-gray-200">{movie.year}</span>
          <span className="text-gray-400 mx-2">|</span>
          <span className="text-gray-200 capitalize">{movie.type}</span>
        </div>
        <p className="text-gray-300 text-sm md:text-base mb-4 line-clamp-3 md:line-clamp-4">
          {movie.description}
        </p>
        <div className="flex space-x-3">
          <Button 
            className="bg-netflix-red hover:bg-netflix-red/80 text-white px-5 py-2"
            onClick={() => navigate(`/details/${movie.id}`)}
          >
            Play
          </Button>
          <Button 
            className="bg-gray-500/70 hover:bg-gray-500/90 text-white px-5 py-2"
            onClick={() => navigate(`/details/${movie.id}`)}
          >
            More Info
          </Button>
        </div>
      </div>
    </div>
  );
};

export default FeatureBanner;
