
import React from 'react';
import { Movie } from '@/services/api';

interface MovieCardProps {
  movie: Movie;
  onClick?: () => void;
}

const MovieCard: React.FC<MovieCardProps> = ({ movie, onClick }) => {
  return (
    <div 
      className="movie-card cursor-pointer group"
      onClick={onClick}
    >
      <div className="relative aspect-[2/3] w-full">
        <img 
          src={movie.imageUrl} 
          alt={movie.title}
          className="object-cover w-full h-full rounded-md"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
          <div>
            <h3 className="text-white font-medium text-sm md:text-base">{movie.title}</h3>
            <div className="flex items-center mt-1">
              <span className="text-green-400 text-xs">{movie.rating.toFixed(1)}</span>
              <span className="mx-2 text-xs text-gray-400">|</span>
              <span className="text-gray-400 text-xs">{movie.year}</span>
            </div>
            <div className="mt-1 flex flex-wrap gap-1">
              {movie.genre.slice(0, 2).map((genre, index) => (
                <span key={index} className="text-[10px] bg-gray-700/80 px-1.5 py-0.5 rounded-sm text-gray-300">
                  {genre}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MovieCard;
