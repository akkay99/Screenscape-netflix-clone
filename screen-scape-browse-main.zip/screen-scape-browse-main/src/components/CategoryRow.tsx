
import React, { useRef } from 'react';
import { Movie } from '@/services/api';
import MovieCard from './MovieCard';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

interface CategoryRowProps {
  title: string;
  movies: Movie[];
}

const CategoryRow: React.FC<CategoryRowProps> = ({ title, movies }) => {
  const rowRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  const handleScroll = (direction: 'left' | 'right') => {
    if (rowRef.current) {
      const { scrollLeft, clientWidth } = rowRef.current;
      const scrollTo = direction === 'left' 
        ? scrollLeft - clientWidth * 0.75 
        : scrollLeft + clientWidth * 0.75;
      
      rowRef.current.scrollTo({
        left: scrollTo,
        behavior: 'smooth'
      });
    }
  };

  if (movies.length === 0) return null;

  return (
    <div className="mb-8">
      <h2 className="text-white text-xl md:text-2xl font-bold mb-4">{title}</h2>
      <div className="relative group">
        <Button 
          className="absolute left-0 top-1/2 z-10 transform -translate-y-1/2 bg-black/30 hover:bg-black/60 rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
          variant="ghost"
          size="icon"
          onClick={() => handleScroll('left')}
        >
          <ChevronLeft className="text-white" size={24} />
        </Button>
        
        <div 
          ref={rowRef}
          className="flex space-x-2 overflow-x-scroll scrollbar-hide pb-4"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {movies.map((movie) => (
            <div key={movie.id} className="flex-none w-[180px] md:w-[220px]">
              <MovieCard 
                movie={movie} 
                onClick={() => navigate(`/details/${movie.id}`)}
              />
            </div>
          ))}
        </div>
        
        <Button 
          className="absolute right-0 top-1/2 z-10 transform -translate-y-1/2 bg-black/30 hover:bg-black/60 rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
          variant="ghost"
          size="icon"
          onClick={() => handleScroll('right')}
        >
          <ChevronRight className="text-white" size={24} />
        </Button>
      </div>
    </div>
  );
};

export default CategoryRow;
