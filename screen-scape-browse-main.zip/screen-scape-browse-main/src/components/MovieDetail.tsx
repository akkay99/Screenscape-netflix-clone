
import React from 'react';
import { Movie } from '@/services/api';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface MovieDetailProps {
  movie: Movie;
  onClose: () => void;
}

const MovieDetail: React.FC<MovieDetailProps> = ({ movie, onClose }) => {
  const navigate = useNavigate();

  return (
    <div className="fixed inset-0 bg-netflix-black/80 z-50 flex items-center justify-center p-4">
      <div className="relative w-full max-w-4xl rounded-lg overflow-hidden bg-netflix-dark-gray max-h-[80vh] flex flex-col animate-fade-in">
        <Button 
          className="absolute top-4 right-4 z-10 bg-netflix-black/60 text-white hover:bg-netflix-black/80 rounded-full"
          size="icon"
          onClick={onClose}
        >
          <X size={24} />
        </Button>
        
        <div className="relative w-full h-[40vh]">
          <img 
            src={movie.imageUrl} 
            alt={movie.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-netflix-dark-gray to-transparent" />
        </div>
        
        <div className="p-6 overflow-y-auto">
          <h1 className="text-white text-2xl md:text-3xl font-bold mb-2">
            {movie.title}
          </h1>
          
          <div className="flex items-center mb-4">
            <span className="text-green-400 mr-2 font-medium">{movie.rating.toFixed(1)} Rating</span>
            <span className="text-gray-400 mx-2">|</span>
            <span className="text-gray-200">{movie.year}</span>
            <span className="text-gray-400 mx-2">|</span>
            <span className="text-gray-200 capitalize">{movie.type}</span>
          </div>
          
          <Button 
            className="bg-netflix-red hover:bg-netflix-red/80 text-white px-6 py-2 mb-6"
          >
            Play
          </Button>
          
          <p className="text-gray-300 mb-6">
            {movie.description}
          </p>
          
          <div className="mb-4">
            <h3 className="text-white text-lg font-medium mb-2">Genres</h3>
            <div className="flex flex-wrap gap-2">
              {movie.genre.map((genre, index) => (
                <span 
                  key={index} 
                  className="px-3 py-1 bg-netflix-medium-gray text-gray-300 rounded-full text-sm"
                >
                  {genre}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MovieDetail;
