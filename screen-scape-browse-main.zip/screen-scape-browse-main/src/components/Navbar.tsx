
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, User } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';

const Navbar = () => {
  const { isAuthenticated, logout } = useAuth();
  const [isScrolled, setIsScrolled] = useState(false);

  React.useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 0) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={cn(
      "fixed top-0 w-full z-50 transition-all duration-500 px-4 md:px-16 py-4 flex items-center justify-between",
      isScrolled ? "bg-netflix-black" : "bg-gradient-to-b from-netflix-black/80 to-transparent"
    )}>
      <div className="flex items-center gap-8">
        <Link to="/" className="text-netflix-red font-bold text-2xl md:text-3xl">SCREENSCAPE</Link>
        <div className="hidden md:flex items-center gap-6">
          <Link to="/" className="text-white hover:text-gray-300 transition">Home</Link>
          <Link to="/movies" className="text-white hover:text-gray-300 transition">Movies</Link>
          <Link to="/series" className="text-white hover:text-gray-300 transition">Series</Link>
        </div>
      </div>
      
      <div className="flex items-center gap-4">
        <Link to="/search">
          <Button variant="ghost" size="icon" className="text-white">
            <Search size={20} />
          </Button>
        </Link>
        
        {isAuthenticated ? (
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" className="text-white">
              <User size={20} />
            </Button>
            <Button 
              variant="ghost" 
              className="text-white hover:text-netflix-red transition"
              onClick={logout}
            >
              Logout
            </Button>
          </div>
        ) : (
          <Link to="/login">
            <Button className="bg-netflix-red hover:bg-netflix-red/80 text-white">
              Sign In
            </Button>
          </Link>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
